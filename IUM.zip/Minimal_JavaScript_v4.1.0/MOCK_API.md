# THE MOCK API

#### DOWNLOAD RESOURCE

https://www.dropbox.com/sh/6ojn099upi105tf/AACpmlqrNUacwbBfVdtt2t6va?dl=0

---

#### SETUP GUIDE

https://docs.minimals.cc/quick-start
